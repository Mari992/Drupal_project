<?php

namespace Drupal\bootstrap_layouts\Annotation;

use Drupal\Component\Annotation\PluginID;

/**
 * Defines a BootstrapLayoutsHandler annotation object.
 *
 * @Annotation
 */
class BootstrapLayoutsHandler extends PluginID {
}
