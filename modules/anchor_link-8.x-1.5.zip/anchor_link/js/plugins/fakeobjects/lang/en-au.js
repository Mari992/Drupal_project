/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'en-au', {
	anchor: 'Anchor', // MISSING
	flash: 'Flash Animation', // MISSING
	hiddenfield: 'Hidden Field', // MISSING
	iframe: 'IFrame', // MISSING
	unknown: 'Unknown Object' // MISSING
} );
